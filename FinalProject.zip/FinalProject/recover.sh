#!/bin/bash

xset r rate
